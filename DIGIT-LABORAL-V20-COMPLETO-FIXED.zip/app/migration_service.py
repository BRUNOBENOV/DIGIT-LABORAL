from __future__ import annotations

import logging
from pathlib import Path

from alembic import command
from alembic.config import Config
from sqlalchemy import create_engine, inspect, text

from .config import settings
from .database import Base, engine, normalize_database_url
from . import models as _models  # noqa: F401  # Register all SQLAlchemy metadata before create_all.

logger = logging.getLogger(__name__)
BASE_DIR = Path(__file__).resolve().parent.parent

# Render can preserve an empty MIGRATION_DATABASE_URL when a Blueprint adds a
# sync:false variable to an existing service. Fall back to DATABASE_URL instead
# of ever creating an engine from an empty value.
_raw_migration_url = (settings.migration_database_url or settings.database_url).strip()
MIGRATION_DATABASE_URL = normalize_database_url(_raw_migration_url)
migration_engine = (
    engine
    if str(engine.url) == MIGRATION_DATABASE_URL
    else create_engine(MIGRATION_DATABASE_URL, pool_pre_ping=True)
)


def _alembic_config() -> Config:
    cfg = Config(str(BASE_DIR / "alembic.ini"))
    cfg.set_main_option("script_location", str(BASE_DIR / "alembic"))
    cfg.set_main_option("sqlalchemy.url", str(migration_engine.url).replace("%", "%%"))
    return cfg


def _reconcile_v20_schema() -> None:
    """Bring fresh, v19 and partially migrated databases to the v20 model.

    v20 mostly adds new tables. ``create_all`` safely creates any table/index
    missing from the final SQLAlchemy model without deleting or rewriting
    existing v19 data. The only changes that can affect already-existing tables
    are applied below using idempotent PostgreSQL DDL.
    """
    Base.metadata.create_all(migration_engine)

    if migration_engine.dialect.name != "postgresql":
        return

    with migration_engine.begin() as connection:
        # These may be missing if an earlier v20 Alembic run was interrupted.
        connection.execute(text(
            "ALTER TABLE IF EXISTS compliance_events "
            "ADD COLUMN IF NOT EXISTS branch_id INTEGER NULL"
        ))
        connection.execute(text(
            "ALTER TABLE IF EXISTS compliance_events "
            "ADD COLUMN IF NOT EXISTS source_key VARCHAR(180) NULL"
        ))
        connection.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_compliance_events_branch_id "
            "ON compliance_events (branch_id)"
        ))
        connection.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_compliance_events_source_key "
            "ON compliance_events (source_key)"
        ))
        connection.execute(text(
            "CREATE INDEX IF NOT EXISTS ix_security_events_ip_address "
            "ON security_events (ip_address)"
        ))
        # PostgreSQL allows multiple NULL values. The partial unique index
        # enforces idempotency only for events that actually have a source key.
        connection.execute(text(
            "CREATE UNIQUE INDEX IF NOT EXISTS uq_compliance_event_source_idx "
            "ON compliance_events (company_id, authority, source_key) "
            "WHERE source_key IS NOT NULL"
        ))


def run_migrations() -> None:
    """Start v20 reliably without losing data from an existing v19 database."""
    cfg = _alembic_config()
    inspector = inspect(migration_engine)
    tables = set(inspector.get_table_names())

    if not tables:
        _reconcile_v20_schema()
        command.stamp(cfg, "head")
        logger.info("Fresh database created and stamped at Alembic head")
        return

    # A previous failed v20 deploy can leave alembic_version at the baseline or
    # another intermediate revision. Reconcile the final schema idempotently,
    # then mark the database as current. This makes repeated Render deploys safe.
    _reconcile_v20_schema()
    command.stamp(cfg, "head", purge=True)
    logger.info("Database reconciled with Digit Laboral v20 and stamped at Alembic head")
