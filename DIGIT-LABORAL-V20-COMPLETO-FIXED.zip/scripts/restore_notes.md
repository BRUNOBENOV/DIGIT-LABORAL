# Restauración de respaldo

## SQLite
1. Detener Digit Laboral.
2. Guardar una copia adicional de `data/digit_laboral.db`.
3. Extraer `database/digit_laboral.db` desde el ZIP.
4. Reemplazar la base y restaurar la carpeta `uploads/`.
5. Iniciar el sistema y comprobar `/health`.

## PostgreSQL
1. Crear una base vacía.
2. Extraer el archivo `.dump`.
3. Ejecutar `pg_restore --clean --if-exists --no-owner --dbname="$DATABASE_URL" archivo.dump`.
4. Restaurar `uploads/` en el almacenamiento persistente.
5. Verificar usuarios, empresas, expedientes, solicitudes y documentos.

Nunca se considera probado un respaldo hasta completar una restauración de ensayo.
