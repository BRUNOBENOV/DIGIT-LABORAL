from __future__ import annotations

import csv
import io
import zipfile
from datetime import UTC, datetime

from openpyxl import load_workbook

from app.backup_service import build_studio_export
from app.database import SessionLocal
from app.import_service import build_employee_template, parse_employee_import
from app.models import Studio
from app.security_service import _totp_at, build_totp_secret, verify_totp


def test_employee_import_template_and_parser():
    payload = build_employee_template()
    workbook = load_workbook(io.BytesIO(payload), read_only=True)
    assert workbook.active.title == 'Funcionarios'
    csv_payload = (
        'nombre_completo;cedula;cargo;fecha_ingreso;salario_base;aporta_ips\n'
        'Ana Pérez;1234567;Auxiliar;01/08/2026;3.200.000;Sí\n'
    ).encode('utf-8')
    rows = parse_employee_import(csv_payload, 'funcionarios.csv')
    assert len(rows) == 1
    assert rows[0].valid
    assert rows[0].data['base_salary'] == 3_200_000
    assert rows[0].data['admission_date'] == '2026-08-01'


def test_totp_verifier_accepts_current_window(monkeypatch):
    secret = build_totp_secret()
    fixed = 1_800_000_000
    monkeypatch.setattr('app.security_service.time.time', lambda: fixed)
    code = _totp_at(secret, fixed // 30)
    assert verify_totp(secret, code)
    assert not verify_totp(secret, '000000') or code == '000000'


def test_complete_studio_export_excludes_passwords(tmp_path):
    with SessionLocal() as db:
        studio = db.query(Studio).first()
        assert studio is not None
        payload = build_studio_export(db, studio, tmp_path)
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        names = set(archive.namelist())
        assert 'manifest.json' in names
        assert 'datos/empresas.csv' in names
        users = archive.read('datos/usuarios.csv').decode('utf-8-sig')
        assert 'password' not in users.lower()


def test_v19_templates_include_new_workflows():
    from pathlib import Path
    root = Path(__file__).resolve().parents[1] / 'app' / 'templates'
    assert 'Importar Excel' in (root / 'employees.html').read_text(encoding='utf-8')
    assert 'Línea de tiempo laboral' in (root / 'employee_detail.html').read_text(encoding='utf-8')
    assert 'Agenda laboral' in (root / 'calendar.html').read_text(encoding='utf-8')
    assert 'Historial de comentarios' in (root / 'request_detail.html').read_text(encoding='utf-8')
    assert 'Seguridad de la cuenta' in (root / 'security.html').read_text(encoding='utf-8')
